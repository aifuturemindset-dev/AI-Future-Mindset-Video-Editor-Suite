#!/bin/bash
# =============================================================
# AI Future Mindset — Batch Merge All Modules
# Loops through every course/module that has raw files
# Usage: ./batch.sh [course_id]
# Example: ./batch.sh                    (all 3 courses)
# Example: ./batch.sh ai-employee-academy (one course only)
# =============================================================

BASE="$(cd "$(dirname "$0")/.." && pwd)"
MERGE="$BASE/scripts/merge.sh"
LOG="$BASE/output/batch-log.txt"

echo "AI Future Mindset — Batch Video Merge" | tee "$LOG"
echo "Started: $(date)" | tee -a "$LOG"
echo "======================================" | tee -a "$LOG"

COURSES=("content-engine" "ai-employee-academy" "solo-studio")
if [ -n "$1" ]; then COURSES=("$1"); fi

PASS=0; FAIL=0; SKIP=0

for COURSE in "${COURSES[@]}"; do
  RAW_BASE="$BASE/raw/$COURSE"
  if [ ! -d "$RAW_BASE" ]; then
    echo "SKIP $COURSE — no raw folder found" | tee -a "$LOG"
    continue
  fi
  for MODULE_DIR in "$RAW_BASE"/*/; do
    MODULE=$(basename "$MODULE_DIR")
    SLIDE="$MODULE_DIR/slide-lesson.mp4"
    DEMO="$MODULE_DIR/screen-demo.mp4"
    if [ ! -f "$SLIDE" ] || [ ! -f "$DEMO" ]; then
      echo "SKIP $COURSE/$MODULE — missing slide-lesson.mp4 or screen-demo.mp4" | tee -a "$LOG"
      ((SKIP++)); continue
    fi
    echo "" | tee -a "$LOG"
    echo ">>> Processing $COURSE / Module $MODULE" | tee -a "$LOG"
    if bash "$MERGE" "$COURSE" "$MODULE" >> "$LOG" 2>&1; then
      echo "PASS $COURSE/$MODULE" | tee -a "$LOG"; ((PASS++))
    else
      echo "FAIL $COURSE/$MODULE — check $LOG" | tee -a "$LOG"; ((FAIL++))
    fi
  done
done

echo "" | tee -a "$LOG"
echo "======================================" | tee -a "$LOG"
echo "Done: $PASS passed | $FAIL failed | $SKIP skipped" | tee -a "$LOG"
echo "Log saved to: $LOG"
