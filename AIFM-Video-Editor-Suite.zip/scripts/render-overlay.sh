#!/bin/bash
# =============================================================
# AI Future Mindset — Render Pure FFmpeg Overlay
# Burns lower-third, step numbers, and keyword directly
# No Remotion needed — uses drawtext filter
# Usage: ./render-overlay.sh <input.mp4> <output.mp4> \
#        "<KEYWORD>" "<Step 1 text>" "<Step 2>" ... (up to 5 steps)
# =============================================================

INPUT="$1"; OUTPUT="$2"; KEYWORD="$3"
S1="${4:-}"; S2="${5:-}"; S3="${6:-}"; S4="${7:-}"; S5="${8:-}"

ACCENT="FF1493"; DARK="0E0B1F"; WHITE="FFFFFF"; CYAN="4DD9E8"
FONT_DIR="/home/claude/video-editor/assets/fonts"

# Build drawtext chain
FILTERS=""

# Upper third — course watermark bar (top 80px)
FILTERS="${FILTERS}drawbox=x=0:y=0:w=iw:h=80:color=${DARK}@0.85:t=fill,"
FILTERS="${FILTERS}drawtext=text='AI Future Mindset':x=30:y=28:fontsize=22:fontcolor=${ACCENT}:fontfile=${FONT_DIR}/Rajdhani-Bold.ttf:alpha=0.95,"

# Keyword — large bold centered
FILTERS="${FILTERS}drawtext=text='${KEYWORD}':x=(w-text_w)/2:y=100:fontsize=68:fontcolor=${WHITE}:fontfile=${FONT_DIR}/Orbitron-Bold.ttf:borderw=3:bordercolor=${ACCENT}:alpha=0.0:enable='lt(t,0.5)',"
FILTERS="${FILTERS}drawtext=text='${KEYWORD}':x=(w-text_w)/2:y=100:fontsize=68:fontcolor=${WHITE}:fontfile=${FONT_DIR}/Orbitron-Bold.ttf:borderw=3:bordercolor=${ACCENT}:alpha='min(1,(t-0.5)/0.4)':enable='gte(t,0.5)',"

# Lower third — semi-transparent bar
FILTERS="${FILTERS}drawbox=x=0:y=ih-140:w=iw:h=140:color=${DARK}@0.88:t=fill,"

# Step circles and text (only show when text provided)
add_step() {
  local N="$1" TEXT="$2" X="$3"
  [ -z "$TEXT" ] && return
  FILTERS="${FILTERS}drawtext=text='${N}':x=${X}:y=ih-100:fontsize=28:fontcolor=${DARK}:fontfile=${FONT_DIR}/Orbitron-Bold.ttf,"
  FILTERS="${FILTERS}drawtext=text='${TEXT}':x=$((X+50)):y=ih-98:fontsize=22:fontcolor=${WHITE}:fontfile=${FONT_DIR}/Rajdhani-SemiBold.ttf,"
}
add_step "1" "$S1" 40
add_step "2" "$S2" 40
add_step "3" "$S3" 680
add_step "4" "$S4" 680
add_step "5" "$S5" 40

# Accent line at bottom
FILTERS="${FILTERS}drawbox=x=0:y=ih-4:w=iw:h=4:color=${ACCENT}@1:t=fill"

# Remove trailing comma
FILTERS="${FILTERS%,}"

ffmpeg -i "$INPUT" -vf "$FILTERS" \
  -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p \
  -c:a copy "$OUTPUT" -y

echo "Overlay rendered: $OUTPUT"
