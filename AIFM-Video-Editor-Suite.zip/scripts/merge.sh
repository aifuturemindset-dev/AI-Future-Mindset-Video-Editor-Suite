#!/bin/bash
# =============================================================
# AI Future Mindset — Video Merge Script
# Merges slide lesson + screen demo for each module
# Adds intro bumper and outro bumper
# Usage: ./merge.sh <course_id> <module_id>
# Example: ./merge.sh ai-employee-academy 01
# =============================================================

set -e

COURSE="${1:-ai-employee-academy}"
MODULE="${2:-01}"
BASE="$(cd "$(dirname "$0")/.." && pwd)"
RAW="$BASE/raw/$COURSE/$MODULE"
OUT="$BASE/output/$COURSE"
ASSETS="$BASE/assets"

mkdir -p "$OUT"

SLIDE="$RAW/slide-lesson.mp4"
DEMO="$RAW/screen-demo.mp4"
INTRO="$ASSETS/intro-bumper.mp4"
OUTRO="$ASSETS/outro-bumper.mp4"
OVERLAY="$ASSETS/overlay-$COURSE-$MODULE.mp4"

echo ""
echo "=== AI Future Mindset Video Merge ==="
echo "Course : $COURSE"
echo "Module : $MODULE"
echo "Output : $OUT"
echo ""

# --- Step 1: Validate inputs ---
for f in "$SLIDE" "$DEMO"; do
  if [ ! -f "$f" ]; then
    echo "ERROR: Missing $f"
    echo "Create the folder: raw/$COURSE/$MODULE/"
    echo "Drop in slide-lesson.mp4 and screen-demo.mp4"
    exit 1
  fi
done

# --- Step 2: Normalize both clips to 1920x1080, 30fps, AAC audio ---
echo "[1/5] Normalizing slide lesson..."
ffmpeg -i "$SLIDE" \
  -vf "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=#0E0B1F" \
  -r 30 -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p \
  -c:a aac -ar 48000 -ac 2 \
  "$OUT/tmp_slide.mp4" -y

echo "[2/5] Normalizing screen demo..."
ffmpeg -i "$DEMO" \
  -vf "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=#0E0B1F" \
  -r 30 -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p \
  -c:a aac -ar 48000 -ac 2 \
  "$OUT/tmp_demo.mp4" -y

# --- Step 3: If overlay exists, composite it onto slide lesson ---
echo "[3/5] Compositing overlay graphics..."
if [ -f "$OVERLAY" ]; then
  ffmpeg -i "$OUT/tmp_slide.mp4" -i "$OVERLAY" \
    -filter_complex "[0:v][1:v] overlay=0:0" \
    -c:v libx264 -preset fast -crf 18 -c:a copy \
    "$OUT/tmp_slide_overlaid.mp4" -y
  mv "$OUT/tmp_slide_overlaid.mp4" "$OUT/tmp_slide.mp4"
else
  echo "  (no overlay file found — skipping composite)"
fi

# --- Step 4: Create concat list ---
echo "[4/5] Concatenating intro + lesson + demo + outro..."
CONCAT="$OUT/concat_$MODULE.txt"
echo "file '$OUT/tmp_slide.mp4'" > "$CONCAT"
echo "file '$OUT/tmp_demo.mp4'" >> "$CONCAT"

# Wrap with intro and outro if they exist
if [ -f "$INTRO" ] && [ -f "$OUTRO" ]; then
  echo "file '$INTRO'" > "$CONCAT"
  echo "file '$OUT/tmp_slide.mp4'" >> "$CONCAT"
  echo "file '$OUT/tmp_demo.mp4'" >> "$CONCAT"
  echo "file '$OUTRO'" >> "$CONCAT"
fi

FINAL="$OUT/${COURSE}-module-${MODULE}.mp4"
ffmpeg -f concat -safe 0 -i "$CONCAT" \
  -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p \
  -c:a aac -ar 48000 -ac 2 \
  "$FINAL" -y

# --- Step 5: Cleanup ---
rm -f "$OUT/tmp_slide.mp4" "$OUT/tmp_demo.mp4" "$CONCAT"

echo ""
echo "[5/5] Done!"
echo "Output: $FINAL"
ffprobe -v quiet -show_entries format=duration -of default=noprint_wrappers=1 "$FINAL"
