#!/bin/bash
# Auto-generated — render overlays for every module
# Run from the video-editor root folder
BASE="$(cd "$(dirname "$0")/.." && pwd)"


# === AI Content Engine ===

# ACE Module 00: Set Up Your AI Content Studio
echo 'Rendering ACE-00...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/content-engine/00/slide-lesson.mp4" \
  "$BASE/assets/overlay-content-engine-00.mp4" \
  "SETUP" \
  "Install Claude Desktop" "Create your Project" "Load brand voice" "Install 8 skills" "Upload to GitHub"


# ACE Module 01: The Viral Content Formula
echo 'Rendering ACE-01...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/content-engine/01/slide-lesson.mp4" \
  "$BASE/assets/overlay-content-engine-01.mp4" \
  "FORMULA" \
  "Hook" "Value" "Format" "CTA" "Score and rank"


# ACE Module 02: AI Research for SEO and AEO
echo 'Rendering ACE-02...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/content-engine/02/slide-lesson.mp4" \
  "$BASE/assets/overlay-content-engine-02.mp4" \
  "RESEARCH" \
  "Topic cluster" "Search intent" "Answer-first writing" "Verify before publish" "Save to Drive"


# ACE Module 03: Short-Form Video
echo 'Rendering ACE-03...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/content-engine/03/slide-lesson.mp4" \
  "$BASE/assets/overlay-content-engine-03.mp4" \
  "SHORT-FORM" \
  "Choose the spec" "Script with hooks" "Film vertical 9x16" "Auto captions" "Post and log"


# ACE Module 04: YouTube Long-Form and Thumbnails
echo 'Rendering ACE-04...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/content-engine/04/slide-lesson.mp4" \
  "$BASE/assets/overlay-content-engine-04.mp4" \
  "LONGFORM" \
  "Package first" "5 title options" "Chapters and re-hooks" "Thumbnail brief in Canva" "Upload with chapters"


# ACE Module 05: Content Repurposing Automation
echo 'Rendering ACE-05...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/content-engine/05/slide-lesson.mp4" \
  "$BASE/assets/overlay-content-engine-05.mp4" \
  "REPURPOSE" \
  "Map the repurpose tree" "Import automation sheet" "Build Make scenario" "Add approval gate" "Test one row end to end"


# ACE Module 06: Marketing and Sales Funnel
echo 'Rendering ACE-06...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/content-engine/06/slide-lesson.mp4" \
  "$BASE/assets/overlay-content-engine-06.mp4" \
  "FUNNEL" \
  "Map 5 stages" "Create lead magnet" "Build keyword DM" "Load email sequence" "Test end to end"


# ACE Module 07: Capstone: 30-Day Content Engine
echo 'Rendering ACE-07...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/content-engine/07/slide-lesson.mp4" \
  "$BASE/assets/overlay-content-engine-07.mp4" \
  "CAPSTONE" \
  "Plan 30 days" "Block weekly rhythm" "Log real metrics" "Day 7 review" "Post your capstone"


# === AI Employee Academy ===

# AEA Module 01: From AI User to AI Leader
echo 'Rendering AEA-01...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/ai-employee-academy/01/slide-lesson.mp4" \
  "$BASE/assets/overlay-ai-employee-academy-01.mp4" \
  "AGENTIC LEADERSHIP" \
  "Install Claude Desktop" "Fill in Path Card" "List 5 repeat tasks" "Circle one" "Post in Skool"


# AEA Module 02: Tour Your Claude Workplace
echo 'Rendering AEA-02...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/ai-employee-academy/02/slide-lesson.mp4" \
  "$BASE/assets/overlay-ai-employee-academy-02.mp4" \
  "WORKPLACE" \
  "Find Chat Cowork Code" "Create your Project" "Add Project instructions" "Review memory settings" "Build first artifact"


# AEA Module 03: Connect Your Tools
echo 'Rendering AEA-03...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/ai-employee-academy/03/slide-lesson.mp4" \
  "$BASE/assets/overlay-ai-employee-academy-03.mp4" \
  "CONNECTORS" \
  "Customize then Connectors" "Connect Google Drive" "Connect Gmail and Calendar" "Review permissions" "Run 3 test prompts"


# AEA Module 04: Give Your AI Employee Skills
echo 'Rendering AEA-04...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/ai-employee-academy/04/slide-lesson.mp4" \
  "$BASE/assets/overlay-ai-employee-academy-04.mp4" \
  "SKILLS" \
  "Browse skill directory" "Upload 8 course skills" "Create skill with skill-creator" "Test your skill" "Install a role plugin"


# AEA Module 05: Delegate with Cowork
echo 'Rendering AEA-05...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/ai-employee-academy/05/slide-lesson.mp4" \
  "$BASE/assets/overlay-ai-employee-academy-05.mp4" \
  "DELEGATE" \
  "Fill 5-part task brief" "Grant folder access only" "Read Claudes plan" "Steer in real time" "Type /schedule"


# AEA Module 06: Build Visuals and Apps
echo 'Rendering AEA-06...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/ai-employee-academy/06/slide-lesson.mp4" \
  "$BASE/assets/overlay-ai-employee-academy-06.mp4" \
  "DESIGN AND ARTIFACTS" \
  "Open Claude Design" "Prompt your design" "Edit on canvas" "Export to Canva or PDF" "Publish your artifact"


# AEA Module 07: Claude Code and Routines
echo 'Rendering AEA-07...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/ai-employee-academy/07/slide-lesson.mp4" \
  "$BASE/assets/overlay-ai-employee-academy-07.mp4" \
  "CODE AND ROUTINES" \
  "Open Code tab" "Create project folder" "Add CLAUDE.md" "Approve plan before changes" "Set up a cloud Routine"


# AEA Module 08: Hire Your First AI Employee
echo 'Rendering AEA-08...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/ai-employee-academy/08/slide-lesson.mp4" \
  "$BASE/assets/overlay-ai-employee-academy-08.mp4" \
  "ROLE CARD" \
  "Complete role-card.md" "Map flowchart with workflow-mapper" "Run once manually in Cowork" "QC with seam-check" "Log run then schedule"


# AEA Module 09: Build Your AI Organization
echo 'Rendering AEA-09...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/ai-employee-academy/09/slide-lesson.mp4" \
  "$BASE/assets/overlay-ai-employee-academy-09.mp4" \
  "AI ORG" \
  "Design 3-role org chart" "Build source-of-truth sheet" "Write handoff rules" "Complete failure-recovery.md" "Write team rollout plan"


# AEA Module 10: Teach It: Train-the-Trainer
echo 'Rendering AEA-10...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/ai-employee-academy/10/slide-lesson.mp4" \
  "$BASE/assets/overlay-ai-employee-academy-10.mp4" \
  "TEACH IT" \
  "Script lesson with lesson-script-writer" "Build slides in Claude Design" "Record slide lesson and screen demo" "Run practice session" "Score rubric and submit capstone"


# === The Solo Studio ===

# SS Module 01: The Creator Business OS
echo 'Rendering SS-01...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/solo-studio/01/slide-lesson.mp4" \
  "$BASE/assets/overlay-solo-studio-01.mp4" \
  "OPERATING SYSTEM" \
  "Map 15 repeat tasks" "Mark frequency and risk" "Circle the one" "Name preparation vs judgment" "Post Day 1 in community"


# SS Module 02: Install Connect and Onboard
echo 'Rendering SS-02...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/solo-studio/02/slide-lesson.mp4" \
  "$BASE/assets/overlay-solo-studio-02.mp4" \
  "INSTALL" \
  "Open Customize then Plugins" "Install Small Business" "Run smb-onboard" "Connect 2 tools only" "Run 3 read-only tests"


# SS Module 03: Your Brand Operating Brief
echo 'Rendering SS-03...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/solo-studio/03/slide-lesson.mp4" \
  "$BASE/assets/overlay-solo-studio-03.mp4" \
  "THE BRIEF" \
  "Write never-list first" "Voice and prohibited claims" "Disclosure rules" "Load into plugin Customize" "Run before and after test"


# SS Module 04: 44 Skills Become 7 Employees
echo 'Rendering SS-04...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/solo-studio/04/slide-lesson.mp4" \
  "$BASE/assets/overlay-solo-studio-04.mp4" \
  "YOUR CREW" \
  "Sort all 44 skills" "Assign to 7 roles" "Write first role card" "Name every never-line" "Hire one first"


# SS Module 05: GATE and BRIEF Weekly Rhythm
echo 'Rendering SS-05...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/solo-studio/05/slide-lesson.mp4" \
  "$BASE/assets/overlay-solo-studio-05.mp4" \
  "RHYTHM" \
  "Run /monday-brief" "Sort inbox with inbox-manager" "Set draft-only rule" "Grade the brief output" "Start your run log"


# SS Module 06: INKWELL The Content Engine
echo 'Rendering SS-06...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/solo-studio/06/slide-lesson.mp4" \
  "$BASE/assets/overlay-solo-studio-06.mp4" \
  "INKWELL" \
  "Run content-strategy" "Set social-content-engine rules" "Approve brief before design" "Run canva-creator" "Publish one approved piece"


# SS Module 07: ECHO Audience Listening
echo 'Rendering SS-07...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/solo-studio/07/slide-lesson.mp4" \
  "$BASE/assets/overlay-solo-studio-07.mp4" \
  "ECHO" \
  "Run review-reputation" "Sort into 3 buckets" "Write escalation rule" "Turn top question to content" "Test ticket-deflector"


# SS Module 08: SCOUT Sponsors and Proposals
echo 'Rendering SS-08...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/solo-studio/08/slide-lesson.mp4" \
  "$BASE/assets/overlay-solo-studio-08.mp4" \
  "SCOUT" \
  "Write rate card first" "Triage with lead-triage" "Draft with speed-to-lead" "Build proposal from notes" "Run contract-review"


# SS Module 09: LEDGER Money and Health
echo 'Rendering SS-09...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/solo-studio/09/slide-lesson.mp4" \
  "$BASE/assets/overlay-solo-studio-09.mp4" \
  "LEDGER" \
  "Connect accounting read-only" "Run cash-flow-snapshot" "Run invoice-chase draft only" "Verify 3 numbers vs source" "Export close packet"


# SS Module 10: FORGE and Capstone
echo 'Rendering SS-10...'
bash "$BASE/scripts/render-overlay.sh" \
  "$BASE/raw/solo-studio/10/slide-lesson.mp4" \
  "$BASE/assets/overlay-solo-studio-10.mp4" \
  "FORGE" \
  "Run build-agent" "Name and save the agent" "Run manually 3 times" "Log every run pass or fail" "Schedule at ladder level 1"
