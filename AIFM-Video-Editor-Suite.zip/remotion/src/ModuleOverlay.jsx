import {AbsoluteFill,useCurrentFrame,useVideoConfig,spring,interpolate,Easing} from "remotion";

const B={dark:"#0E0B1F",panel:"#171331",accent:"#FF1493",cyan:"#4DD9E8",amber:"#FFC24D",white:"#F3EEFF",muted:"#A89FCB"};
const T={primary:"Orbitron, system-ui, sans-serif",secondary:"Rajdhani, system-ui, sans-serif",accent:"Caveat, cursive"};

function StepBadge({n,delay,color}){
  const f=useCurrentFrame();
  const sc=spring({frame:f-delay,fps:30,config:{stiffness:200,damping:18}});
  return(
    <div style={{width:52,height:52,borderRadius:"50%",background:color||B.accent,display:"flex",alignItems:"center",justifyContent:"center",transform:`scale(${sc})`,boxShadow:`0 0 20px ${(color||B.accent)}88`,flexShrink:0}}>
      <span style={{fontFamily:T.primary,fontWeight:800,fontSize:22,color:B.dark}}>{n}</span>
    </div>
  );
}

function StepRow({n,text,delay,color}){
  const f=useCurrentFrame();
  const op=interpolate(f-delay,[0,12],[0,1],{extrapolateLeft:"clamp",extrapolateRight:"clamp"});
  const tx=interpolate(f-delay,[0,12],[24,0],{extrapolateLeft:"clamp",extrapolateRight:"clamp"});
  if(!text)return null;
  return(
    <div style={{display:"flex",alignItems:"center",gap:14,opacity:op,transform:`translateX(${tx}px)`}}>
      <StepBadge n={n} delay={0} color={color}/>
      <span style={{fontFamily:T.secondary,fontWeight:600,fontSize:24,color:B.white,lineHeight:1.2}}>{text}</span>
    </div>
  );
}

function KeywordBanner({keyword,color}){
  const f=useCurrentFrame();
  const op=interpolate(f,[0,18],[0,1],{extrapolateLeft:"clamp",extrapolateRight:"clamp"});
  const sc=interpolate(f,[0,18],[0.85,1],{extrapolateLeft:"clamp",extrapolateRight:"clamp"});
  return(
    <div style={{position:"absolute",top:88,left:0,right:0,display:"flex",justifyContent:"center",opacity:op,transform:`scale(${sc})`}}>
      <div style={{background:`linear-gradient(135deg,${(color||B.accent)}22,${B.panel})`,border:`2px solid ${color||B.accent}`,borderRadius:14,padding:"14px 52px",boxShadow:`0 0 44px ${(color||B.accent)}55`}}>
        <span style={{fontFamily:T.primary,fontWeight:800,fontSize:54,color:B.white,letterSpacing:3,textShadow:`0 0 32px ${color||B.accent}`}}>{keyword}</span>
      </div>
    </div>
  );
}

function UpperThird({courseTitle,moduleNum,color}){
  const f=useCurrentFrame();
  const op=interpolate(f,[0,10],[0,1],{extrapolateLeft:"clamp",extrapolateRight:"clamp"});
  return(
    <div style={{position:"absolute",top:0,left:0,right:0,height:76,background:`${B.dark}DD`,display:"flex",alignItems:"center",padding:"0 36px",gap:24,opacity:op,borderBottom:`1.5px solid ${(color||B.accent)}44`}}>
      <span style={{fontFamily:T.primary,fontWeight:700,fontSize:19,color:color||B.accent,letterSpacing:2}}>AI FUTURE MINDSET</span>
      <div style={{flex:1}}/>
      <span style={{fontFamily:T.secondary,fontWeight:600,fontSize:19,color:B.muted}}>{courseTitle}</span>
      <div style={{width:6,height:6,borderRadius:"50%",background:color||B.accent}}/>
      <span style={{fontFamily:T.primary,fontWeight:700,fontSize:17,color:color||B.accent}}>MODULE {moduleNum}</span>
    </div>
  );
}

function LowerThird({steps,color}){
  const validSteps=steps.filter(Boolean).slice(0,5);
  const rows=[[0,1],[2,3],[4]];
  return(
    <div style={{position:"absolute",bottom:0,left:0,right:0,background:`${B.dark}EE`,borderTop:`2px solid ${color||B.accent}`,padding:"20px 40px 28px"}}>
      {rows.map((pair,ri)=>(
        <div key={ri} style={{display:"flex",gap:60,marginBottom:ri<rows.length-1?14:0}}>
          {pair.map(idx=>validSteps[idx]!=null&&(
            <StepRow key={idx} n={idx+1} text={validSteps[idx]} delay={idx*4} color={color}/>
          ))}
        </div>
      ))}
    </div>
  );
}

function AccentLine({color}){
  const f=useCurrentFrame();
  const w=interpolate(f,[0,25],[0,100],{extrapolateLeft:"clamp",extrapolateRight:"clamp"});
  return <div style={{position:"absolute",bottom:0,left:0,height:4,width:`${w}%`,background:`linear-gradient(90deg,${color||B.accent},${B.cyan})`,boxShadow:`0 0 16px ${color||B.accent}`}}/>;
}

export const ModuleOverlay=({keyword="KEYWORD",steps=[],courseTitle="Course",moduleNum="01",color})=>(
  <AbsoluteFill style={{background:"transparent"}}>
    <UpperThird courseTitle={courseTitle} moduleNum={moduleNum} color={color}/>
    <KeywordBanner keyword={keyword} color={color}/>
    <LowerThird steps={steps} color={color}/>
    <AccentLine color={color}/>
  </AbsoluteFill>
);
