import {Composition} from "remotion";
import {ModuleOverlay} from "./ModuleOverlay";

export const RemotionRoot=()=>(
  <>
    <Composition id="ModuleOverlay" component={ModuleOverlay}
      durationInFrames={150} fps={30} width={1920} height={1080}
      defaultProps={{keyword:"AGENTIC LEADERSHIP",steps:["Install Claude Desktop","Fill in Path Card","List 5 repeat tasks","Circle one","Post in Skool"],courseTitle:"AI Employee Academy",moduleNum:"01",color:"#FF1493"}}
    />
  </>
);
